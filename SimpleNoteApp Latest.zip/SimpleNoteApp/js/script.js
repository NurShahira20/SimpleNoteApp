let notes = [];
let currentNoteId = null;


function loadNotes() {
    const storedNotes = localStorage.getItem('notes');
    if (storedNotes) {
        notes = JSON.parse(storedNotes); 
    }
}

function saveNotesToLocalStorage() {
    localStorage.setItem('notes', JSON.stringify(notes)); // Save notes to localStorage
}

function openNoteEditor(noteId = null) {
    const modal = document.getElementById('noteModal');
    modal.style.display = 'block';  // Add note

    if (noteId) {
        const note = notes.find(n => n.id === noteId);
        currentNoteId = noteId;
        document.getElementById('noteTitle').value = note.title;
        document.getElementById('noteContent').value = note.content;
        document.getElementById('noteCategory').value = note.category;
        document.getElementById('noteDate').value = note.date;
        document.getElementById('notePriority').value = note.priority;
        document.getElementById('reminder-date').value = note.reminderDate || '';
        document.getElementById('reminder-time').value = note.reminderTime || '';
        document.getElementById('modalTitle').textContent = 'Edit Note';
        if (note.image) {
            document.getElementById('image-preview').src = note.image;
            document.getElementById('image-preview').style.display = 'block';
        }
        if (note.textColor) {
            document.getElementById('noteContent').style.color = note.textColor; 
        }
    } else {
        currentNoteId = null;
        document.getElementById('noteTitle').value = '';
        document.getElementById('noteContent').value = '';
        document.getElementById('noteCategory').value = 'personal';
        document.getElementById('noteDate').value = '';
        document.getElementById('notePriority').value = 'low';
        document.getElementById('reminder-date').value = '';
        document.getElementById('reminder-time').value = '';
        document.getElementById('modalTitle').textContent = 'Add Note';
        document.getElementById('image-preview').style.display = 'none';
        document.getElementById('noteContent').style.color = '#000000'; 
    }
}

function closeNoteEditor() {
    document.getElementById('noteModal').style.display = 'none';  
}

function saveNote() {
    const title = document.getElementById('noteTitle').value;
    const content = document.getElementById('noteContent').value;
    const date = document.getElementById('noteDate').value;
    const category = document.getElementById('noteCategory').value;
    const reminderDate = document.getElementById('reminder-date').value;
    const reminderTime = document.getElementById('reminder-time').value;
    const priority = document.getElementById('notePriority').value;
    const imagePreview = document.getElementById('image-preview');
    const textColor = document.getElementById('noteContent').style.color; 

    const image = imagePreview.style.display === 'block' ? imagePreview.src : null;

    // Validation if no input in title,content,date
    if (!title.trim() || !content.trim() || !date.trim()) {
        
        alert('Please fill in the Title, Content, and Date fields before saving.');
        return;  
    }

    // Edit Note if got ID
    if (currentNoteId) {
        const noteIndex = notes.findIndex(n => n.id === currentNoteId);
        notes[noteIndex] = {
            id: currentNoteId,
            title,
            content,
            category,
            date,
            reminderDate,
            reminderTime,
            priority,
            image,
            textColor, 
            createdAt: notes[noteIndex].createdAt,
            updatedAt: new Date()
        };
    } else {
        // Add Note if no ID
        const newNote = {
            id: Date.now(),
            title,
            content,
            category,
            date,
            reminderDate,
            reminderTime,
            priority,
            image,
            textColor, // Store the color
            createdAt: new Date(),
            updatedAt: new Date()
        };
        notes.push(newNote);
    }

    saveNotesToLocalStorage(); // Save the notes to localStorage
    closeNoteEditor();
    renderNotes();
}


function deleteNote(noteId) {
    notes = notes.filter(n => n.id !== noteId);
    saveNotesToLocalStorage(); // Save update notes 
    renderNotes();
}

function filterNotes() {
    const searchQuery = document.getElementById('searchInput').value.toLowerCase();
    renderNotes(searchQuery);
}

function renderNotes(searchQuery = '') {
    const notesList = document.getElementById('notesList');
    notesList.innerHTML = '';  

    // Filter notes use search 
    const filteredNotes = notes.filter(note => {
        return note.title.toLowerCase().includes(searchQuery) ||
            note.category.toLowerCase().includes(searchQuery) ||
            note.priority.toLowerCase().includes(searchQuery);
    });

    // Sort note priority
    filteredNotes.sort((a, b) => {
        const priorityOrder = { 'high': 1, 'medium': 2, 'low': 3 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

   
    filteredNotes.forEach(note => {
        const noteElement = document.createElement('div');
        noteElement.className = 'note';

      
        let categoryStyle = '';
        switch (note.category) {
            case 'personal':
                categoryStyle = 'background-color: pink; color: #fff; border: 2px solid #e91e63;';
                break;
            case 'work':
                categoryStyle = 'background-color: blue; color: #fff; border: 2px solid #2196f3;';
                break;
            case 'study':
                categoryStyle = 'background-color: yellow; color: #000; border: 2px solid #ffeb3b;';
                break;
            case 'ideas':
                categoryStyle = 'background-color: purple; color: #fff; border: 2px solid #9c27b0;';
                break;
            case 'finance':
                categoryStyle = 'background-color: green; color: #fff; border: 2px solid #4caf50;';
                break;
            case 'shopping':
                categoryStyle = 'background-color: orange; color: #fff; border: 2px solid #ff9800;';
                break;
            default:
                categoryStyle = 'background-color: gray; color: #fff;';
        }

        noteElement.innerHTML = `
            <h4 style="text-transform: capitalize; ${categoryStyle}">${note.category}</h4> <!-- Category with style -->
            <h3>${note.title}</h3>
            <p style="color: ${note.textColor};">${note.content}</p> <!-- Apply text color here -->
            <small>Date: ${note.date}</small><br>
            <small>Priority: ${note.priority}</small><br>
            ${note.image ? `<img src="${note.image}" style="max-width: 100%; margin-top: 10px;">` : ''}
            ${note.reminderDate ? `<small>Reminder: ${note.reminderDate} ${note.reminderTime}</small><br>` : ''}
            <button onclick="openNoteEditor(${note.id})">Edit</button>
            <button onclick="deleteNote(${note.id})">Delete</button>
        `;
        notesList.appendChild(noteElement);
    });
}



loadNotes();
renderNotes();


function changeStyle(style) {
    let noteBox = document.getElementById('noteContent');
    if (style === 'bold') {
        noteBox.style.fontWeight = noteBox.style.fontWeight === 'bold' ? 'normal' : 'bold';
    } else if (style === 'italic') {
        noteBox.style.fontStyle = noteBox.style.fontStyle === 'italic' ? 'normal' : 'italic';
    } else if (style === 'underline') {
        noteBox.style.textDecoration = noteBox.style.textDecoration === 'underline' ? 'none' : 'underline';
    }
}



function changeFont(font) {
    document.getElementById('noteContent').style.fontFamily = font;
}

// Change text color 
function changeTextColor(color) {
    document.getElementById('noteContent').style.color = color;
}

// Handle image upload
function handleImageUpload(event) {
    let imagePreview = document.getElementById('image-preview');
    let file = event.target.files[0];

    if (file) {
        let reader = new FileReader();
        reader.onload = function (e) {
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block'; 
        };
        reader.readAsDataURL(file);
    }
}


function setPriorityOrder() {
    const priority = document.getElementById('notePriority').value;
    const options = document.getElementById('notePriority').options;
    let optionArray = Array.from(options);
    optionArray.sort((a, b) => {
        return a.value === 'high' ? -1 : a.value === 'medium' ? 0 : 1;
    });

    optionArray.forEach(option => {
        options.add(option);
    });
}

// Open the note editor
function openNoteEditor(noteId = null) {
    const modal = document.getElementById('noteModal');
    modal.style.display = 'block';  

   
    document.body.classList.add('modal-open');


    if (noteId) {
        const note = notes.find(n => n.id === noteId);
        currentNoteId = noteId;
        document.getElementById('noteTitle').value = note.title;
        document.getElementById('noteContent').value = note.content;
        document.getElementById('noteCategory').value = note.category;
        document.getElementById('noteDate').value = note.date;
        document.getElementById('notePriority').value = note.priority;
        document.getElementById('reminder-date').value = note.reminderDate || '';
        document.getElementById('reminder-time').value = note.reminderTime || '';
        document.getElementById('modalTitle').textContent = 'Edit Note';
        if (note.image) {
            document.getElementById('image-preview').src = note.image;
            document.getElementById('image-preview').style.display = 'block';
        }
        if (note.textColor) {
            document.getElementById('noteContent').style.color = note.textColor; 
        }
    } else {
        currentNoteId = null;
        document.getElementById('noteTitle').value = '';
        document.getElementById('noteContent').value = '';
        document.getElementById('noteCategory').value = 'personal';
        document.getElementById('noteDate').value = '';
        document.getElementById('notePriority').value = 'low';
        document.getElementById('reminder-date').value = '';
        document.getElementById('reminder-time').value = '';
        document.getElementById('modalTitle').textContent = 'Add Note';
        document.getElementById('image-preview').style.display = 'none';
        document.getElementById('noteContent').style.color = '#000000'; 
    }
}

// Close the note editor
function closeNoteEditor() {
    document.getElementById('noteModal').style.display = 'none';  


    document.body.classList.remove('modal-open');
}


window.addEventListener('click', function (e) {
    const modal = document.getElementById('noteModal');
    if (e.target === modal) {
        closeNoteEditor();
    }
});

